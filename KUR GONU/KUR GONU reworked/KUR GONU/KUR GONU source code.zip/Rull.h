#ifndef _GAME_DATA_H_
# include "GameData.h"
#endif

void killPiece( Piece* killed ); 
int isDefeated( int player );
int isCastleCaptured( int player );